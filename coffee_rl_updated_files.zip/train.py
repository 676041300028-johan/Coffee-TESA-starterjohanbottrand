import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import SubprocVecEnv
from stable_baselines3.common.callbacks import EvalCallback, CheckpointCallback
from stable_baselines3.common.monitor import Monitor
from market_env import CoffeeAuctionEnv

BASE_DIR = Path(__file__).resolve().parent
MODELS_DIR = BASE_DIR / "models"


def make_env(total_rounds: int, rank: int, is_eval: bool = False, sp_path: str = None, sp_teams: int = 0):
    def _init():
        seed = (9000 + rank) if is_eval else (100 + rank)
        env = CoffeeAuctionEnv(
            num_teams=55,
            total_rounds=total_rounds,
            seed=seed,
            self_play_model_path=sp_path,
            self_play_teams=sp_teams,
        )
        return Monitor(env)
    return _init


def _find_existing_model(profile_name: str) -> Optional[Path]:
    p_final = MODELS_DIR / f"{profile_name}_final.zip"
    if p_final.exists():
        return p_final
    p_best = MODELS_DIR / profile_name / "best" / "best_model.zip"
    if p_best.exists():
        return p_best
    return None


def _sync_saved_model(src_zip: Path, profile_name: str, set_as_default_best: bool = False):
    final_path = MODELS_DIR / f"{profile_name}_final.zip"
    shutil.copy2(src_zip, final_path)

    latest_best_dir = MODELS_DIR / profile_name / "best"
    latest_best_dir.mkdir(parents=True, exist_ok=True)
    try:
        shutil.copy2(src_zip, latest_best_dir / "best_model.zip")
    except PermissionError:
        pass

    if set_as_default_best:
        default_best = MODELS_DIR / "best"
        default_best.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copy2(src_zip, default_best / "best_model.zip")
            shutil.copy2(src_zip, MODELS_DIR / "coffee_rl_v2_final.zip")
        except PermissionError:
            pass


def run_alternating_80_20_league(
    steps_9r_per_cycle: int = 200_000,   # 80% ของเวลา: เน้นปั้นตัว 9 รอบเจอคู่แข่งโหด
    steps_16r_per_cycle: int = 50_000,   # 20% ของเวลา: จูนตัว 16 รอบให้รับมือ SNIPER/HOARDER/PANIC
    self_play_teams: int = 8,
):
    run_tag = datetime.now().strftime("%Y%m%d_%H%M%S")
    num_cpu = 4

    p9_dir = MODELS_DIR / "coffee_rl_9rounds"
    p16_dir = MODELS_DIR / "coffee_rl_16rounds_event"
    best9_dir = p9_dir / f"best_{run_tag}"
    best16_dir = p16_dir / f"best_{run_tag}"
    ckpt9_dir = p9_dir / "checkpoints"
    ckpt16_dir = p16_dir / "checkpoints"
    log9_dir = p9_dir / "logs"
    log16_dir = p16_dir / "logs"

    for d in (best9_dir, best16_dir, ckpt9_dir, ckpt16_dir, log9_dir, log16_dir):
        d.mkdir(parents=True, exist_ok=True)

    champ_9r = _find_existing_model("coffee_rl_9rounds")
    champ_16r = _find_existing_model("coffee_rl_16rounds_event")

    if champ_9r is None:
        print("=" * 90)
        print("[WARMUP 9-ROUNDS] สร้างโมเดลเริ่มต้นโหมด 9 รอบ (Action 3D) สู้คู่แข่งโหด 150,000 steps")
        print("=" * 90)
        env_w = SubprocVecEnv([make_env(9, i, is_eval=False) for i in range(num_cpu)])
        eval_w = SubprocVecEnv([make_env(9, 0, is_eval=True)])
        cb_w = EvalCallback(
            eval_w, best_model_save_path=str(best9_dir), log_path=str(log9_dir),
            eval_freq=max(5000 // num_cpu, 1000), n_eval_episodes=20, deterministic=True
        )
        m_w = PPO(
            "MlpPolicy", env_w, learning_rate=3e-4, n_steps=2048, batch_size=256,
            n_epochs=10, gamma=0.995, ent_coef=0.012, verbose=1
        )
        m_w.learn(total_timesteps=150_000, callback=[cb_w])
        snap9 = ckpt9_dir / f"coffee_rl_9rounds_gen0_{run_tag}.zip"
        if (best9_dir / "best_model.zip").exists():
            shutil.copy2(best9_dir / "best_model.zip", snap9)
        else:
            m_w.save(str(snap9))
        champ_9r = snap9
        _sync_saved_model(champ_9r, "coffee_rl_9rounds", set_as_default_best=False)
        env_w.close()
        eval_w.close()

    cycle = 1
    while True:
        lr_9 = max(5e-5, 1.8e-4 * (0.88 ** (cycle - 1)))
        ent_9 = max(0.002, 0.006 * (0.88 ** (cycle - 1)))

        print("=" * 90)
        print(f"[CYCLE #{cycle} | 80% -> โหมด 9 รอบ] คู่แข่งโหด (SNIPER/HOARDER/PANIC) + Self-Play 8 ทีม ({steps_9r_per_cycle:,} steps)")
        print("=" * 90)

        env9 = SubprocVecEnv([
            make_env(9, i, is_eval=False, sp_path=str(champ_9r), sp_teams=self_play_teams)
            for i in range(num_cpu)
        ])
        eval9 = SubprocVecEnv([
            make_env(9, 0, is_eval=True, sp_path=str(champ_9r), sp_teams=self_play_teams)
        ])

        try:
            model9 = PPO.load(str(champ_9r), env=env9, learning_rate=lr_9, ent_coef=ent_9)
        except ValueError:
            model9 = PPO(
                "MlpPolicy", env9, learning_rate=2.5e-4, n_steps=2048, batch_size=256,
                n_epochs=10, gamma=0.995, ent_coef=0.01, verbose=1
            )

        cb9 = EvalCallback(
            eval9, best_model_save_path=str(best9_dir), log_path=str(log9_dir),
            eval_freq=max(5000 // num_cpu, 1000), n_eval_episodes=25, deterministic=True
        )
        ckpt9 = CheckpointCallback(
            save_freq=max(50_000 // num_cpu, 5000), save_path=str(ckpt9_dir),
            name_prefix=f"coffee_rl_9r_c{cycle}_{run_tag}"
        )
        model9.learn(total_timesteps=steps_9r_per_cycle, callback=[cb9, ckpt9], reset_num_timesteps=False)

        next_9 = ckpt9_dir / f"coffee_rl_9rounds_c{cycle}_{run_tag}.zip"
        if (best9_dir / "best_model.zip").exists():
            shutil.copy2(best9_dir / "best_model.zip", next_9)
        else:
            model9.save(str(next_9))
        champ_9r = next_9
        _sync_saved_model(champ_9r, "coffee_rl_9rounds", set_as_default_best=False)
        env9.close()
        eval9.close()
        print(f"อัปเดตตัว 9 รอบเรียบร้อย -> {MODELS_DIR / 'coffee_rl_9rounds_final.zip'}")
        print()

        if champ_16r is not None and champ_16r.exists():
            print("=" * 90)
            print(f"[CYCLE #{cycle} | 20% -> โหมด 16 รอบ] จูนตัวเก่งรับมือ SNIPER/HOARDER/PANIC + Self-Play ({steps_16r_per_cycle:,} steps)")
            print("=" * 90)

            env16 = SubprocVecEnv([
                make_env(16, i, is_eval=False, sp_path=str(champ_16r), sp_teams=self_play_teams)
                for i in range(num_cpu)
            ])
            eval16 = SubprocVecEnv([
                make_env(16, 0, is_eval=True, sp_path=str(champ_16r), sp_teams=self_play_teams)
            ])

            model16 = PPO.load(str(champ_16r), env=env16, learning_rate=5e-5, ent_coef=0.002)
            cb16 = EvalCallback(
                eval16, best_model_save_path=str(best16_dir), log_path=str(log16_dir),
                eval_freq=max(5000 // num_cpu, 1000), n_eval_episodes=20, deterministic=True
            )
            model16.learn(total_timesteps=steps_16r_per_cycle, callback=[cb16], reset_num_timesteps=False)

            next_16 = ckpt16_dir / f"coffee_rl_16rounds_c{cycle}_{run_tag}.zip"
            if (best16_dir / "best_model.zip").exists():
                shutil.copy2(best16_dir / "best_model.zip", next_16)
            else:
                model16.save(str(next_16))
            champ_16r = next_16
            _sync_saved_model(champ_16r, "coffee_rl_16rounds_event", set_as_default_best=True)
            env16.close()
            eval16.close()
            print(f"อัปเดตตัว 16 รอบเรียบร้อย -> {MODELS_DIR / 'coffee_rl_16rounds_event_final.zip'}")
            print()

        cycle += 1


if __name__ == "__main__":
    run_alternating_80_20_league(
        steps_9r_per_cycle=200_000,   # 80%
        steps_16r_per_cycle=50_000,   # 20%
        self_play_teams=8,
    )
